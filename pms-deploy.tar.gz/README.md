# CKCM Payroll Management System

A comprehensive payroll management system built for Christ the King College De Maranding (CKCM) using modern web technologies.

## 🚀 Features

- **User Authentication**: Secure login with credentials and Google OAuth
- **Role-Based Access Control**: Admin and Personnel roles with different permissions
- **Attendance Management**: Time tracking, punch in/out, attendance reports
- **Payroll Processing**: Automated salary calculations, deductions, and payslip generation
- **Loan Management**: Employee loan tracking and management
- **Holiday & Event Management**: Calendar integration for holidays and events
- **Reports & Analytics**: Comprehensive reporting dashboard
- **Data Management**: User management, department management, and data retention

## 🛠️ Tech Stack

- **Framework**: Next.js 15.5.3 (App Router)
- **Frontend**: React 19.1, Tailwind CSS v4, shadcn/ui
- **Authentication**: NextAuth.js v4 with JWT sessions
- **Database**: MySQL with Prisma ORM 6.16
- **Validation**: Zod 4.1.5
- **Forms**: React Hook Form
- **Notifications**: React Hot Toast
- **PDF Generation**: React PDF Renderer
- **Charts**: Recharts

## 📋 Prerequisites

- Node.js 18+ 
- MySQL database (XAMPP recommended)
- Git

## 🚀 Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/Cjblack21/ckcm-payroll.git
   cd ckcm-payroll
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create a `.env.local` file in the root directory:
   ```env
   # Database Configuration
   DATABASE_URL="mysql://root:@localhost:3306/ckcm_payroll"
   
   # NextAuth.js Configuration
   NEXTAUTH_URL="http://localhost:3000"
   NEXTAUTH_SECRET="your-secret-key-here"
   
   # Google OAuth Configuration (Optional)
   GOOGLE_CLIENT_ID="your-google-client-id"
   GOOGLE_CLIENT_SECRET="your-google-client-secret"
   ```

4. **Set up the database**
   ```bash
   npx prisma db push
   npx prisma db seed
   ```

5. **Start the development server**
   ```bash
   npm run dev
   ```

6. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## 🗄️ Database Schema

The system uses MySQL with the following main entities:
- **Users**: Employee accounts with role-based access
- **Attendance**: Time tracking records
- **Payroll**: Salary calculations and payments
- **Loans**: Employee loan management
- **Departments**: Organizational structure
- **Holidays & Events**: Calendar management

## 🔐 Authentication

- **Credentials Provider**: Email/password authentication
- **Google OAuth**: Restricted to @ckcm.edu.ph domain
- **JWT Sessions**: Secure session management
- **Role-Based Access**: ADMIN and PERSONNEL roles

## 📱 User Roles

### Admin
- Full system access
- User management
- Payroll processing
- System configuration
- Reports and analytics

### Personnel
- Personal dashboard
- Attendance tracking
- Payroll viewing
- Loan management
- Profile management

## 🚀 Deployment

### Production Environment Variables
```env
DATABASE_URL="your-production-database-url"
NEXTAUTH_URL="https://your-domain.com"
NEXTAUTH_SECRET="your-production-secret"
GOOGLE_CLIENT_ID="your-production-google-client-id"
GOOGLE_CLIENT_SECRET="your-production-google-client-secret"
```

### Build for Production
```bash
npm run build
npm start
```

## 📁 Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── admin/             # Admin-only pages
│   ├── personnel/         # Personnel pages
│   ├── api/               # API routes
│   └── auth/              # Authentication pages
├── components/            # Reusable UI components
│   └── ui/               # shadcn/ui components
├── lib/                  # Utility functions and configurations
│   ├── actions/          # Server actions
│   └── validations/      # Zod schemas
└── hooks/                # Custom React hooks
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Support

For support and questions, please contact the development team or create an issue in the repository.

## 🔄 Version History

- **v2.1.0**: Current version with Next.js 15, React 19, and enhanced authentication
- **v2.0.0**: Major refactor with App Router and improved UI
- **v1.0.0**: Initial release with basic payroll functionality

---

**Developed for Christ the King College De Maranding**  
*Advanced Payroll Management System*#   c k c m - p a y r o l l - 1  
 