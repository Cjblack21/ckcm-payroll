import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get userId
    let userId = session.user.id as string | undefined
    if (!userId && session.user.email) {
      const user = await prisma.user.findUnique({
        where: { email: session.user.email },
        select: { users_id: true }
      })
      userId = user?.users_id
    }
    if (!userId) {
      return NextResponse.json({ error: 'User ID not found' }, { status: 401 })
    }

    // Get period from query params
    const searchParams = request.nextUrl.searchParams
    const periodStartStr = searchParams.get('periodStart')
    const periodEndStr = searchParams.get('periodEnd')

    if (!periodStartStr || !periodEndStr) {
      return NextResponse.json({ error: 'Missing period parameters' }, { status: 400 })
    }

    const periodStart = new Date(periodStartStr)
    const periodEnd = new Date(periodEndStr)

    // Get all deductions for this user (not filtered by period)
    const deductions = await prisma.deduction.findMany({
      where: {
        users_id: userId
      },
      include: {
        deductionType: {
          select: {
            name: true,
            amount: true
          }
        }
      },
      orderBy: {
        appliedAt: 'desc'
      }
    })

    // Separate attendance vs other deductions
    const isAttendanceType = (name: string) => (
      name.includes('Late') || name.includes('Absent') || name.includes('Early')
    )
    const otherDeductions = deductions.filter(d => !isAttendanceType(d.deductionType.name))

    // Get attendance records for this period
    const attendanceSettingsForCalc = await prisma.attendanceSettings.findFirst()
    const timeInEnd = attendanceSettingsForCalc?.timeInEnd || '09:30'
    
    // Calculate working days
    let workingDaysInPeriod = 0
    {
      const cur = new Date(periodStart)
      while (cur <= periodEnd) {
        if (cur.getDay() !== 0) workingDaysInPeriod++
        cur.setDate(cur.getDate() + 1)
      }
      if (workingDaysInPeriod === 0) workingDaysInPeriod = 22
    }

    const user = await prisma.user.findUnique({ 
      where: { users_id: userId }, 
      select: { personnelType: { select: { basicSalary: true } } } 
    })
    const basicSalary = user?.personnelType?.basicSalary ? Number(user.personnelType.basicSalary) : 0

    const attendanceRecords = await prisma.attendance.findMany({
      where: { users_id: userId, date: { gte: periodStart, lte: periodEnd } },
      orderBy: { date: 'asc' }
    })

    let attendanceDeductionsTotal = 0
    const attendanceDetails: { date: Date, type: string, amount: number }[] = []
    
    for (const rec of attendanceRecords) {
      if (rec.status === 'LATE' && rec.timeIn) {
        const timeIn = new Date(rec.timeIn)
        const expected = new Date(rec.date)
        const [h, m] = timeInEnd.split(':').map(Number)
        const adjM = m + 1
        if (adjM >= 60) {
          expected.setHours(h + 1, adjM - 60, 0, 0)
        } else {
          expected.setHours(h, adjM, 0, 0)
        }
        const perSecond = (basicSalary / workingDaysInPeriod / 8 / 60 / 60)
        const secondsLate = Math.max(0, (timeIn.getTime() - expected.getTime()) / 1000)
        const daily = basicSalary / workingDaysInPeriod
        const amount = Math.min(secondsLate * perSecond, daily * 0.5)
        if (amount > 0) {
          attendanceDeductionsTotal += amount
          attendanceDetails.push({ date: rec.date, type: 'Late', amount })
        }
      } else if (rec.status === 'ABSENT') {
        const amount = basicSalary / workingDaysInPeriod
        attendanceDeductionsTotal += amount
        attendanceDetails.push({ date: rec.date, type: 'Absent', amount })
      } else if (rec.status === 'PARTIAL') {
        let hoursShort = 0
        if (rec.timeIn && rec.timeOut) {
          const timeIn = new Date(rec.timeIn)
          const timeOut = new Date(rec.timeOut)
          const hoursWorked = Math.max(0, (timeOut.getTime() - timeIn.getTime()) / (1000 * 60 * 60))
          hoursShort = Math.max(0, 8 - hoursWorked)
        } else {
          hoursShort = 8
        }
        const hourlyRate = (basicSalary / workingDaysInPeriod) / 8
        const amount = hoursShort * hourlyRate
        if (amount > 0) {
          attendanceDeductionsTotal += amount
          attendanceDetails.push({ date: rec.date, type: 'Partial', amount })
        }
      }
    }

    // Get active loans
    const loans = await prisma.loan.findMany({
      where: {
        users_id: userId,
        status: 'ACTIVE'
      }
    })

    // Get unpaid leaves for this period
    const unpaidLeaveRequests = await prisma.leaveRequest.findMany({
      where: {
        users_id: userId,
        status: 'APPROVED',
        isPaid: false,
        startDate: { lte: periodEnd },
        endDate: { gte: periodStart }
      },
      orderBy: { startDate: 'asc' }
    })

    let totalUnpaidLeaveDays = 0
    const leaveDetails: { leaveType: string; startDate: Date; endDate: Date; days: number; amount: number }[] = []
    
    for (const leave of unpaidLeaveRequests) {
      const leaveStart = new Date(leave.startDate) > periodStart ? new Date(leave.startDate) : periodStart
      const leaveEnd = new Date(leave.endDate) < periodEnd ? new Date(leave.endDate) : periodEnd
      
      let leaveDays = 0
      let currentDate = new Date(leaveStart)
      while (currentDate <= leaveEnd) {
        if (currentDate.getDay() !== 0) leaveDays++
        currentDate.setDate(currentDate.getDate() + 1)
      }
      
      totalUnpaidLeaveDays += leaveDays
      
      if (leaveDays > 0) {
        const dailySalary = workingDaysInPeriod > 0 ? basicSalary / workingDaysInPeriod : 0
        const leaveAmount = leaveDays * dailySalary
        leaveDetails.push({
          leaveType: leave.type,
          startDate: new Date(leave.startDate),
          endDate: new Date(leave.endDate),
          days: leaveDays,
          amount: leaveAmount
        })
      }
    }

    const totalUnpaidLeaveDeduction = leaveDetails.reduce((sum, leave) => sum + leave.amount, 0)
    const totalDatabaseDeductions = otherDeductions.reduce((sum, deduction) => sum + Number(deduction.amount), 0)

    const periodDays = Math.floor((periodEnd.getTime() - periodStart.getTime()) / (1000 * 60 * 60 * 24)) + 1
    const factor = periodDays <= 16 ? 0.5 : 1.0
    const totalLoanPayments = loans.reduce((sum, loan) => {
      const monthlyPayment = (Number(loan.amount) * Number(loan.monthlyPaymentPercent)) / 100
      return sum + (monthlyPayment * factor)
    }, 0)

    return NextResponse.json({
      otherDeductions: otherDeductions.map(d => ({
        name: d.deductionType.name,
        amount: Number(d.amount),
        appliedAt: d.appliedAt
      })),
      attendanceDetails: attendanceDetails.map(a => ({ ...a, date: a.date })),
      attendanceDeductionsTotal,
      databaseDeductionsTotal: totalDatabaseDeductions,
      loans: loans.map(l => ({
        purpose: l.purpose,
        amount: Number(l.amount),
        monthlyPaymentPercent: Number(l.monthlyPaymentPercent),
        status: l.status
      })),
      unpaidLeaves: leaveDetails,
      unpaidLeaveDeductionTotal: totalUnpaidLeaveDeduction,
      unpaidLeaveDays: totalUnpaidLeaveDays,
      totalDeductions: totalDatabaseDeductions + attendanceDeductionsTotal + totalLoanPayments + totalUnpaidLeaveDeduction,
      totalLoanPayments
    })

  } catch (error) {
    console.error('Error fetching breakdown:', error)
    return NextResponse.json({ error: 'Failed to fetch breakdown' }, { status: 500 })
  }
}
