"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Calendar, DollarSign, FileText, Archive, Clock, TrendingUp, TrendingDown } from 'lucide-react'
import { format } from 'date-fns'

interface PayrollData {
  currentPayroll: any
  archivedPayrolls: any[]
  periodInfo: {
    current: {
      start: string
      end: string
      releaseTime?: string
    }
  }
  breakdown: {
    otherDeductions: any[]
    attendanceDetails: { date: string; type: string; amount: number }[]
    attendanceDeductionsTotal: number
    databaseDeductionsTotal: number
    loans: any[]
    unpaidLeaves?: { leaveType: string; startDate: string; endDate: string; days: number; amount: number }[]
    unpaidLeaveDeductionTotal?: number
    unpaidLeaveDays?: number
    totalDeductions: number
    totalLoanPayments: number
  }
}

export default function PersonnelPayrollPage() {
  const [data, setData] = useState<PayrollData | null>(null)
  const [loading, setLoading] = useState(true)
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [archiveOpen, setArchiveOpen] = useState(false)
  const [selectedPayroll, setSelectedPayroll] = useState<any>(null)
  const [selectedBreakdown, setSelectedBreakdown] = useState<any>(null)
  const [loadingBreakdown, setLoadingBreakdown] = useState(false)
  const [timeUntilRelease, setTimeUntilRelease] = useState('')
  const [canRelease, setCanRelease] = useState(false)

  useEffect(() => {
    loadPayrollData()
  }, [])

  const loadPayrollData = async () => {
    try {
      setLoading(true)
      console.log('Loading payroll data...')
      
      const response = await fetch('/api/personnel/payroll', { cache: 'no-store' })
      console.log('Response status:', response.status)
      console.log('Response ok:', response.ok)
      
      if (response.ok) {
        const payrollData = await response.json()
        console.log('Payroll data received:', payrollData)
        setData(payrollData)
      } else {
        let errorPayload: any = {}
        try {
          const ct = response.headers.get('content-type') || ''
          if (ct.includes('application/json')) {
            errorPayload = await response.json()
          } else {
            const text = await response.text()
            errorPayload = { message: text.slice(0, 300) }
          }
        } catch {}
        console.error('Failed to load payroll data:', {
          status: response.status,
          statusText: response.statusText,
          error: errorPayload
        })
        // Show user-friendly error message
        alert(`Failed to load payroll data: ${errorPayload?.error || errorPayload?.message || 'Unknown error'}`)
      }
    } catch (error) {
      console.error('Error loading payroll data:', error)
      alert(`Network error: ${error instanceof Error ? error.message : 'Unknown error'}`)
    } finally {
      setLoading(false)
    }
  }

  const testPayrollAPI = async () => {
    try {
      console.log('Testing payroll API...')
      const response = await fetch('/api/test-payroll')
      const testData = await response.json()
      console.log('Test API response:', testData)
      alert(`Test API Response: ${JSON.stringify(testData, null, 2)}`)
    } catch (error) {
      console.error('Test API error:', error)
      alert(`Test API Error: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  const createTestPayroll = async () => {
    try {
      console.log('Creating test payroll...')
      const response = await fetch('/api/create-test-payroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      })
      const result = await response.json()
      console.log('Create test payroll response:', result)
      
      if (response.ok) {
        alert(`Test payroll created successfully! ${result.message}`)
        // Reload the payroll data
        loadPayrollData()
      } else {
        alert(`Failed to create test payroll: ${result.error}`)
      }
    } catch (error) {
      console.error('Create test payroll error:', error)
      alert(`Error creating test payroll: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  const viewDetails = async (payroll: any) => {
    setSelectedPayroll(payroll)
    setSelectedBreakdown(null) // Reset
    setDetailsOpen(true)
    setLoadingBreakdown(true)
    
    // Fetch breakdown data for this specific payroll period
    try {
      console.log('Fetching breakdown for period:', payroll.periodStart, 'to', payroll.periodEnd)
      const response = await fetch(`/api/personnel/payroll/breakdown?periodStart=${payroll.periodStart}&periodEnd=${payroll.periodEnd}`)
      console.log('Breakdown response status:', response.status)
      
      if (response.ok) {
        const breakdown = await response.json()
        console.log('Breakdown data received:', breakdown)
        
        // If breakdown has no details but payroll has deductions, show generic entry
        if (selectedPayroll.deductions > 0 && 
            (!breakdown.otherDeductions || breakdown.otherDeductions.length === 0) &&
            (!breakdown.attendanceDetails || breakdown.attendanceDetails.length === 0) &&
            (!breakdown.loans || breakdown.loans.length === 0)) {
          breakdown.otherDeductions = [{
            name: 'Various Deductions',
            amount: Number(selectedPayroll.deductions),
            appliedAt: selectedPayroll.periodStart
          }]
          breakdown.databaseDeductionsTotal = Number(selectedPayroll.deductions)
        }
        
        setSelectedBreakdown(breakdown)
      } else {
        console.error('Breakdown fetch failed:', response.status, response.statusText)
        const errorText = await response.text()
        console.error('Error response:', errorText)
        // Use current breakdown as fallback
        setSelectedBreakdown(data?.breakdown || null)
      }
    } catch (error) {
      console.error('Error fetching breakdown:', error)
      setSelectedBreakdown(data?.breakdown || null)
    } finally {
      setLoadingBreakdown(false)
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP'
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'MMM dd, yyyy')
  }

  // Timer to update countdown every second
  useEffect(() => {
    if (!data?.periodInfo?.current?.end || !data?.periodInfo?.current?.releaseTime) {
      setTimeUntilRelease('')
      return
    }

    const updateCountdown = () => {
      const now = new Date()
      const releaseTime = data.periodInfo.current.releaseTime || '17:00'
      const [hours, minutes] = releaseTime.split(':').map(Number)
      
      // Create release date time using period end date
      const releaseDateTime = new Date(data.periodInfo.current.end)
      releaseDateTime.setHours(hours, minutes, 0, 0)
      
      const diff = releaseDateTime.getTime() - now.getTime()
      
      if (diff <= 0) {
        setTimeUntilRelease('Release available now!')
        if (!canRelease) {
          setCanRelease(true)
        }
        return
      }
      
      // If counting down, ensure canRelease is false
      if (canRelease) {
        setCanRelease(false)
      }
      
      const days = Math.floor(diff / (1000 * 60 * 60 * 24))
      const hrs = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const secs = Math.floor((diff % (1000 * 60)) / 1000)
      
      let countdown = ''
      if (days > 0) countdown += `${days}d `
      countdown += `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
      
      setTimeUntilRelease(countdown)
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    
    return () => clearInterval(interval)
  }, [data?.periodInfo?.current?.end, data?.periodInfo?.current?.releaseTime, canRelease])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading payroll data...</p>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-gray-600">Failed to load payroll data</p>
          <div className="mt-4 space-x-2">
            <Button onClick={loadPayrollData}>
              Try Again
            </Button>
            <Button onClick={testPayrollAPI} variant="outline">
              Test API
            </Button>
            <Button onClick={createTestPayroll} variant="secondary">
              Create Test Payroll
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const { currentPayroll, archivedPayrolls, periodInfo, breakdown } = data

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">My Payroll</h1>
          <p className="text-gray-600">View your current and archived payroll information</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={archiveOpen} onOpenChange={setArchiveOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Archive className="w-4 h-4 mr-2" />
                View Archive
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Payroll Archive</DialogTitle>
                <DialogDescription>
                  View your previous payroll records
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                {archivedPayrolls.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">No archived payroll records found</p>
                ) : (
                  archivedPayrolls.map((payroll) => (
                    <Card key={payroll.payroll_entries_id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">
                              {formatDate(payroll.periodStart)} - {formatDate(payroll.periodEnd)}
                            </p>
                            <p className="text-sm text-gray-600">
                              Net Pay: {formatCurrency(Number(payroll.netPay))}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={payroll.status === 'RELEASED' ? 'default' : 'secondary'}>
                              {payroll.status}
                            </Badge>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => viewDetails(payroll)}
                            >
                              <FileText className="w-4 h-4 mr-1" />
                              Details
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Release Countdown Timer - Only show if payroll exists (was generated) */}
      {!canRelease && currentPayroll && currentPayroll.status !== 'RELEASED' && timeUntilRelease && (
        <Card className="border-2 border-yellow-500 dark:border-yellow-700 bg-yellow-50 dark:bg-yellow-950/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-800 dark:text-yellow-400 mb-1">Payroll Release Countdown</p>
                <p className="text-xs text-yellow-600 dark:text-yellow-500">
                  Release available on {formatDate(periodInfo.current.end)}
                  {periodInfo.current.releaseTime && ` at ${periodInfo.current.releaseTime}`}
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-yellow-700 dark:text-yellow-500 mb-1">Release in:</p>
                <div className="text-4xl font-bold font-mono text-yellow-900 dark:text-yellow-400 tracking-wider">
                  {timeUntilRelease}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Release Ready Banner - Only show if payroll exists (was generated) */}
      {canRelease && currentPayroll && currentPayroll.status !== 'RELEASED' && (
        <Card className="border-2 border-orange-500 dark:border-orange-700 bg-orange-50 dark:bg-orange-950/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-center gap-3">
              <div className="text-4xl">✓</div>
              <div>
                <p className="text-lg font-bold text-orange-800 dark:text-orange-400">Payroll Release Available!</p>
                <p className="text-sm text-orange-600 dark:text-orange-500">Your payroll will be released soon</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Current Pay Period Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Current Pay Period
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Period Start</p>
              <p className="font-medium">{formatDate(periodInfo.current.start)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Period End</p>
              <p className="font-medium">{formatDate(periodInfo.current.end)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current Payroll */}
      {currentPayroll ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Current Payroll
            </CardTitle>
            <CardDescription>
              Your payroll for the current period
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            {/* Summary Cards - Clean Design */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
              <Card className="border-l-4 border-l-green-500">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Basic Salary</p>
                  <p className="text-xl font-semibold">
                    {formatCurrency(Number(currentPayroll.basicSalary))}
                  </p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-red-500">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Deductions</p>
                  <p className="text-xl font-semibold text-red-600 dark:text-red-400">
                    {formatCurrency(Number(currentPayroll.deductions))}
                  </p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-primary">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Net Pay</p>
                  <p className="text-xl font-semibold text-primary">
                    {formatCurrency(Number(currentPayroll.netPay))}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {((Number(currentPayroll.netPay) / Number(currentPayroll.basicSalary)) * 100).toFixed(1)}% of basic
                  </p>
                </CardContent>
              </Card>
            </div>
            
            {/* Status and Action */}
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Badge variant={currentPayroll.status === 'RELEASED' ? 'default' : 'secondary'}>
                  {currentPayroll.status}
                </Badge>
                {currentPayroll.releasedAt && (
                  <span className="text-sm text-muted-foreground">
                    Released: {formatDate(currentPayroll.releasedAt)}
                  </span>
                )}
              </div>
              <Button onClick={() => viewDetails(currentPayroll)}>
                <FileText className="w-4 h-4 mr-2" />
                View Details
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-8 text-center">
            <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Current Payroll</h3>
            <p className="text-gray-600">
              No payroll has been generated for the current period yet.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Payroll Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="w-[95vw] max-w-[1400px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">
              Payroll Details
            </DialogTitle>
            <DialogDescription>
              Detailed breakdown of your payroll
            </DialogDescription>
          </DialogHeader>
          
          {selectedPayroll && (
            <div className="space-y-6">
              {/* Period Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-600">Pay Period</p>
                  <p className="font-medium">
                    {formatDate(selectedPayroll.periodStart)} - {formatDate(selectedPayroll.periodEnd)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Status</p>
                  <Badge variant={selectedPayroll.status === 'RELEASED' ? 'default' : 'secondary'}>
                    {selectedPayroll.status}
                  </Badge>
                </div>
              </div>

              {/* Earnings Breakdown */}
              <div>
                <h4 className="font-medium mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  Earnings
                </h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Basic Salary (Biweekly)</TableCell>
                      <TableCell className="text-right">
                        {formatCurrency(Number(selectedPayroll.basicSalary))}
                      </TableCell>
                    </TableRow>
                    <TableRow className="font-medium">
                      <TableCell>Total Earnings</TableCell>
                      <TableCell className="text-right">
                        {formatCurrency(Number(selectedPayroll.basicSalary))}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              {/* Deductions Breakdown */}
              <div>
                <h4 className="font-medium mb-3 flex items-center gap-2">
                  <TrendingDown className="w-4 h-4 text-red-600" />
                  Deductions
                </h4>
                
                {loadingBreakdown ? (
                  <div className="py-8 text-center text-muted-foreground">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-900 mx-auto mb-2"></div>
                    Loading breakdown...
                  </div>
                ) : (
                <div className="space-y-4">
                  {/* Deduction Breakdown Card */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <TrendingDown className="h-4 w-4" />
                        Deduction Breakdown
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {/* Other Deductions */}
                      {selectedBreakdown?.otherDeductions && selectedBreakdown.otherDeductions.length > 0 && (
                        selectedBreakdown.otherDeductions.map((deduction: any, index: number) => (
                          <div key={index} className="flex justify-between items-center py-2 border-b last:border-0">
                            <span className="font-medium text-sm">{deduction.name}</span>
                            <span className="text-sm text-red-600 dark:text-red-400">-{formatCurrency(Number(deduction.amount))}</span>
                          </div>
                        ))
                      )}
                      
                      {/* Show total if no individual deductions */}
                      {(!selectedBreakdown?.otherDeductions || selectedBreakdown.otherDeductions.length === 0) &&
                       (!selectedBreakdown?.attendanceDetails || selectedBreakdown.attendanceDetails.length === 0) &&
                       (!selectedBreakdown?.loans || selectedBreakdown.loans.length === 0) &&
                       (!selectedBreakdown?.unpaidLeaves || selectedBreakdown.unpaidLeaves.length === 0) && (
                        <div className="flex justify-between items-center py-3 text-muted-foreground">
                          <span className="text-sm">No detailed breakdown available</span>
                          <span className="text-sm font-medium">{formatCurrency(Number(selectedPayroll.deductions))}</span>
                        </div>
                      )}
                      
                      {/* Total */}
                      <div className="flex justify-between items-center pt-3 border-t font-semibold">
                        <span>Total Deductions</span>
                        <span className="text-red-600 dark:text-red-400">{formatCurrency(Number(selectedPayroll.deductions))}</span>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Attendance Details Card */}
                  {selectedBreakdown?.attendanceDetails && selectedBreakdown.attendanceDetails.length > 0 && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          Attendance Details
                        </CardTitle>
                        <CardDescription className="text-xs">
                          {selectedBreakdown.attendanceDetails.length} {selectedBreakdown.attendanceDetails.length === 1 ? 'day' : 'days'}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date</TableHead>
                              <TableHead>Type</TableHead>
                              <TableHead className="text-right">Deduction</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedBreakdown.attendanceDetails.map((item, idx) => (
                              <TableRow key={`attd-${idx}`}>
                                <TableCell>{formatDate(item.date)}</TableCell>
                                <TableCell>{item.type}</TableCell>
                                <TableCell className="text-right text-red-600 dark:text-red-400">-{formatCurrency(item.amount)}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Other Deductions Card */}
                  {selectedBreakdown?.otherDeductions && selectedBreakdown.otherDeductions.length > 0 && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          Other Deductions
                        </CardTitle>
                        <CardDescription className="text-xs">
                          {selectedBreakdown.otherDeductions.length} {selectedBreakdown.otherDeductions.length === 1 ? 'item' : 'items'}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Type</TableHead>
                              <TableHead>Description</TableHead>
                              <TableHead className="text-right">Amount</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedBreakdown.otherDeductions.map((deduction: any, index: number) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{deduction.name}</TableCell>
                                <TableCell className="text-muted-foreground text-sm">-</TableCell>
                                <TableCell className="text-right text-red-600 dark:text-red-400">-{formatCurrency(Number(deduction.amount))}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  )}
                </div>
                )}
              </div>

              {/* Net Pay Summary */}
              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-medium">Net Pay</span>
                  <span className="text-2xl font-bold text-purple-600">
                    {formatCurrency(Number(selectedPayroll.netPay))}
                  </span>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}





